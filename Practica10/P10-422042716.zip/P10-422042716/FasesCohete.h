#pragma once
/*
  FasesCohete.h  -  Practica 10: de los keyframes a la matriz de cada pieza del cohete

  El cohete son 4 piezas (los 4 .obj). Se ordenan de abajo hacia arriba segun su altura:
      pieza mas baja  -> etapa 0 (se separa primero)
      ...
      pieza mas alta  -> la capsula de la punta: nunca se separa y es la que queda orbitando

  - Mientras una etapa sigue unida, se mueve igual que la nave.
  - A partir de su keyframe de separacion, la etapa deja la nave: su centro avanza desde el punto
    donde se separo (dx dy dz de los keyframes) y gira sobre su propio centro.
  - Una etapa que cae nunca atraviesa el piso: si la caja de la pieza queda por debajo de y = 0
    se levanta justo lo necesario, asi las piezas se apoyan sobre el piso sea cual sea su tamano.

  Las medidas (caja minimo/maximo de cada .obj) se leen de los modelos, por eso los keyframes
  no dependen del tamano del cohete.
*/
#include <algorithm>
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include "Keyframes.h"

const int PARTES = 4;                     // piezas del cohete (Cohete_Parte0..3.obj)

struct Medidas
{
	glm::vec3 minimo, maximo;             // caja que contiene la pieza (coordenadas del modelo)
	glm::vec3 centro() const { return (minimo + maximo) * 0.5f; }
};

class CoheteFases
{
public:
	CoheteFases()
	{
		for (int i = 0; i < PARTES; i++)
		{
			med[i].minimo = glm::vec3(-1.0f, 2.0f * i, -1.0f);       // valores de emergencia
			med[i].maximo = glm::vec3(1.0f, 2.0f * i + 2.0f, 1.0f);
			orden[i] = i;
		}
	}

	// m[i] = medidas de la pieza i. Ordena las piezas de abajo hacia arriba.
	void Configurar(const Medidas m[PARTES])
	{
		for (int i = 0; i < PARTES; i++) { med[i] = m[i]; orden[i] = i; }
		std::stable_sort(orden, orden + PARTES, [this](int a, int b) {
			return med[a].centro().y < med[b].centro().y; });
	}

	// pieza (0..3) que se separa en la etapa k; k = 3 es la capsula
	int Pieza(int k) const { return orden[k]; }
	const Medidas& Medida(int pieza) const { return med[pieza]; }

	// Etapa k separada en el instante t?
	static bool Separada(const kf::Animacion& a, int k, float t)
	{
		int s = a.Separacion(k);
		return s >= 0 && t >= s * kf::DURACION_SEGMENTO - 1e-4f;
	}

	// Matriz de la nave: se mueve en XYZ, rumbo sobre Y y cabeceo sobre Z (0 = apunta hacia arriba)
	static glm::mat4 MatrizNave(const kf::Frame& f)
	{
		glm::mat4 m = glm::translate(glm::mat4(1.0f), glm::vec3(f.x(), f.y(), f.z()));
		m = glm::rotate(m, glm::radians(f.guinada()), glm::vec3(0.0f, 1.0f, 0.0f));
		return glm::rotate(m, glm::radians(f.cabeceo()), glm::vec3(0.0f, 0.0f, 1.0f));
	}

	// Matriz de modelo de cada pieza en el instante t (salida indexada por numero de pieza)
	void Calcular(const kf::Animacion& a, float t, glm::mat4 salida[PARTES]) const
	{
		if (a.Cantidad() == 0)
		{
			for (int i = 0; i < PARTES; i++) salida[i] = glm::mat4(1.0f);
			return;
		}
		kf::Frame f = a.Evaluar(t);
		glm::mat4 nave = MatrizNave(f);
		for (int i = 0; i < PARTES; i++) salida[i] = nave;           // todas unidas

		for (int k = 0; k < kf::ETAPAS; k++)
		{
			if (!Separada(a, k, t)) continue;
			int pieza = orden[k];
			const kf::Frame& fs = a.Obtener(a.Separacion(k));        // pose de la nave al separarse
			glm::vec3 c = med[pieza].centro();
			glm::vec3 separacion = glm::vec3(MatrizNave(fs) * glm::vec4(c, 1.0f));   // donde estaba el centro
			glm::vec3 centro = separacion + glm::vec3(f.ex(k), f.ey(k), f.ez(k));
			glm::mat4 R = glm::rotate(glm::mat4(1.0f), glm::radians(fs.guinada()), glm::vec3(0.0f, 1.0f, 0.0f));
			R = glm::rotate(R, glm::radians(fs.cabeceo() + f.egiro(k)), glm::vec3(0.0f, 0.0f, 1.0f));
			glm::mat4 m = glm::translate(glm::mat4(1.0f), centro) * R * glm::translate(glm::mat4(1.0f), -c);

			// no atravesar el piso
			float bajo = 1e9f;
			for (int e = 0; e < 8; e++)
			{
				glm::vec3 esquina((e & 1) ? med[pieza].maximo.x : med[pieza].minimo.x,
								  (e & 2) ? med[pieza].maximo.y : med[pieza].minimo.y,
								  (e & 4) ? med[pieza].maximo.z : med[pieza].minimo.z);
				bajo = std::min(bajo, (m * glm::vec4(esquina, 1.0f)).y);
			}
			if (bajo < 0.0f) m = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -bajo, 0.0f)) * m;
			salida[pieza] = m;
		}
	}

	// Motor que sigue encendido: la base de la pieza mas baja que todavia esta unida.
	// pos = punto de salida del humo, escape = hacia donde sale (opuesto a la nariz).
	void Motor(const kf::Animacion& a, float t, glm::vec3& pos, glm::vec3& escape) const
	{
		int pieza = orden[PARTES - 1];                               // si ya se separaron todas: la capsula
		for (int k = 0; k < kf::ETAPAS; k++)
			if (!Separada(a, k, t)) { pieza = orden[k]; break; }
		glm::mat4 m = MatrizNave(a.Evaluar(t));
		glm::vec3 c = med[pieza].centro();
		pos = glm::vec3(m * glm::vec4(c.x, med[pieza].minimo.y, c.z, 1.0f));
		escape = -glm::normalize(glm::vec3(m * glm::vec4(0.0f, 1.0f, 0.0f, 0.0f)));
	}

private:
	Medidas med[PARTES];
	int orden[PARTES];                    // orden[k] = pieza que se separa en la etapa k (orden[3] = capsula)
};
