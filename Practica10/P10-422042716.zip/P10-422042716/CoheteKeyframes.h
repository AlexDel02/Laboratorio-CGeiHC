#pragma once
#include <array>
#include <algorithm>
#include <vector>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <iostream>
#include <cmath>
#include "Model.h"
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>

// Cada cuadro almacena tiempo y cuatro poses independientes: X Y Z giroZ.
struct PoseEtapa { glm::vec3 posicion{0}; float giro = 0; };
struct CuadroCohete { double tiempo = 0; std::array<PoseEtapa, 4> piezas; };

class CoheteKeyframes {
public:
    std::vector<CuadroCohete> cuadros;
    std::array<PoseEtapa, 4> pose;
    const glm::vec3 origen{-20, 0, 220};
    float AlturaCapsula() const { return pose[3].posicion.y; }
    glm::vec3 CentroOrbita() const {
        return origen + glm::vec3(0, cuadros[inicioOrbita].piezas[3].posicion.y, 0);
    }
    bool Cargar() {
        const char* nombres[] = {"Etapa1", "Etapa2", "Etapa3", "Capsula"};
        for (int i = 0; i < 4; ++i) {
            modelos[i].LoadModel(std::string("Models/Cohete/Cohete_") + nombres[i] + ".obj");
            if (!modelos[i].EstaCargado()) return false;
            centros[i] = (modelos[i].getMinimo() + modelos[i].getMaximo()) * 0.5f;
        }
        return Leer();
    }
    bool Leer() {
        std::ifstream f("keyframescohete.txt");
        std::string cabecera, extra; int n = 0;
        if (!(f >> cabecera >> n) || cabecera != "COHETE_ETAPAS_V1" || n < 2 || n > 500) return Error();
        std::vector<CuadroCohete> nuevos(n);
        for (int k = 0; k < n; ++k) {
            auto& c = nuevos[k];
            if (!(f >> c.tiempo) || !std::isfinite(c.tiempo) || c.tiempo < 0 || c.tiempo > 3600 ||
                (k && c.tiempo <= nuevos[k-1].tiempo)) return Error();
            for (auto& p : c.piezas) {
                if (!(f >> p.posicion.x >> p.posicion.y >> p.posicion.z >> p.giro)) return Error();
                if (!std::isfinite(p.posicion.x) || !std::isfinite(p.posicion.y) ||
                    !std::isfinite(p.posicion.z) || !std::isfinite(p.giro) ||
                    glm::length(p.posicion) > 3000 || std::abs(p.giro) > 360) return Error();
            }
        }
        if (nuevos.front().tiempo != 0 || nuevos.back().tiempo <= 16 || (f >> extra)) return Error();
        const auto inicio = std::find_if(nuevos.begin(), nuevos.end(),
            [](const CuadroCohete& c) { return c.tiempo == 16; });
        if (inicio == nuevos.end()) return Error();
        for (int i = 0; i < 4; ++i) {
            if (glm::length(inicio->piezas[i].posicion - nuevos.back().piezas[i].posicion) > 0.01f ||
                std::abs(inicio->piezas[i].giro - nuevos.back().piezas[i].giro) > 0.01f) return Error();
        }
        inicioOrbita = size_t(inicio - nuevos.begin());
        cuadros.swap(nuevos); Reiniciar();
        std::cout << "Leidos " << cuadros.size() << " keyframes.\n"; Imprimir(0); return true;
    }
    bool Escribir() const {
        std::ofstream f("keyframescohete.txt", std::ios::trunc);
        f << "COHETE_ETAPAS_V1\n" << cuadros.size() << '\n' << std::fixed << std::setprecision(3);
        for (const auto& c : cuadros) {
            f << c.tiempo;
            for (const auto& p : c.piezas) f << ' ' << p.posicion.x << ' ' << p.posicion.y << ' ' << p.posicion.z << ' ' << p.giro;
            f << '\n';
        }
        f.close();
        std::cout << (f ? "Keyframes sobrescritos en keyframescohete.txt\n" : "ERROR al escribir keyframes\n");
        if (f) for (size_t k = 0; k < cuadros.size(); ++k) Imprimir(k);
        return bool(f);
    }
    void Alternar() { reproduciendo = !reproduciendo; std::cout << (reproduciendo ? "Reproduciendo\n" : "Pausa\n"); }
    void Reiniciar() { tiempo = 0; tramo = 0; reproduciendo = false; if (!cuadros.empty()) pose = cuadros[0].piezas; }
    void Paso() { // Inspeccion exacta de cada cuadro para las capturas.
        if (cuadros.empty()) return;
        reproduciendo = false; tramo = (tramo + 1) % cuadros.size();
        tiempo = cuadros[tramo].tiempo; pose = cuadros[tramo].piezas; Imprimir(tramo);
    }
    void Actualizar(double dt) {
        if (!reproduciendo || cuadros.size() < 2 || !std::isfinite(dt) || dt <= 0) return;
        double restante = dt;
        // Consumir el tiempo hasta cada frontera evita perder cuadros con pocos FPS.
        while (restante > 0) {
            if (tramo + 1 == cuadros.size()) {
                tramo = inicioOrbita;
                tiempo = cuadros[tramo].tiempo;
                std::cout << "Orbita: nuevo ciclo\n";
            }
            double paso = std::min(restante, cuadros[tramo+1].tiempo - tiempo);
            tiempo += paso; restante -= paso;
            if (tiempo >= cuadros[tramo+1].tiempo) { ++tramo; Imprimir(tramo); }
        }
        if (tramo + 1 == cuadros.size()) { pose = cuadros.back().piezas; return; }
        float u = float((tiempo - cuadros[tramo].tiempo) / (cuadros[tramo+1].tiempo - cuadros[tramo].tiempo));
        for (int i = 0; i < 4; ++i) {
            for (int eje = 0; eje < 3; ++eje)
                pose[i].posicion[eje] = Interpolar(i, eje, u);
            pose[i].giro = Interpolar(i, 3, u);
        }
    }
    void Dibujar(GLuint uniformModel) {
        for (int i = 0; i < 4; ++i) {
            glm::mat4 rotacion = glm::rotate(glm::mat4(1), glm::radians(pose[i].giro), glm::vec3(0,0,1));
            // Apoyo real de los vertices rotados: ninguna pieza atraviesa el piso.
            float apoyo = 0;
            for (const auto& v : modelos[i].getVertices())
                apoyo = std::max(apoyo, -(rotacion * glm::vec4((v-centros[i])*12.0f, 1)).y);
            glm::vec3 posicion = pose[i].posicion; posicion.y = std::max(posicion.y, apoyo);
            glm::mat4 m = glm::translate(glm::mat4(1), origen + posicion) * rotacion;
            m = glm::scale(m, glm::vec3(12)); m = glm::translate(m, -centros[i]);
            glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(m)); modelos[i].RenderModel();
        }
    }
    void Imprimir(size_t k) const {
        const auto& c = cuadros[k];
        std::cout << "KEYFRAME " << k << " t=" << c.tiempo;
        for (int i = 0; i < 4; ++i) {
            const auto& p = c.piezas[i];
            std::cout << " | pieza " << i+1 << ": " << p.posicion.x << ' ' << p.posicion.y << ' ' << p.posicion.z << ' ' << p.giro;
        }
        std::cout << '\n';
    }
private:
    float Valor(size_t k, int pieza, int eje) const {
        const PoseEtapa& p = cuadros[k].piezas[pieza];
        return eje == 3 ? p.giro : p.posicion[eje];
    }

    // Tangente de Hermite del ejercicio, ajustada a tiempos no uniformes.
    // En el cierre de la orbita se usan los mismos vecinos a ambos lados.
    float Tangente(size_t k, int pieza, int eje) const {
        if (k == 0) return 0;
        const size_t ultimo = cuadros.size() - 1;
        size_t anterior = k - 1;
        size_t siguiente = k + 1;
        size_t centro = k;
        if (cuadros[k].tiempo == 16 || k == ultimo) {
            centro = inicioOrbita;
            anterior = ultimo - 1;
            siguiente = inicioOrbita + 1;
        }
        const double dtAnterior = centro == inicioOrbita
            ? cuadros.back().tiempo - cuadros[anterior].tiempo
            : cuadros[centro].tiempo - cuadros[anterior].tiempo;
        const double dtSiguiente = cuadros[siguiente].tiempo - cuadros[centro].tiempo;
        const float actual = Valor(centro, pieza, eje);
        const float d0 = (actual - Valor(anterior, pieza, eje)) / float(dtAnterior);
        const float d1 = (Valor(siguiente, pieza, eje) - actual) / float(dtSiguiente);
        return d0 * d1 > 0 ? 2 * d0 * d1 / (d0 + d1) : 0;
    }

    float Interpolar(int pieza, int eje, float u) const {
        const float duracion = float(cuadros[tramo+1].tiempo - cuadros[tramo].tiempo);
        const float p0 = Valor(tramo, pieza, eje);
        const float p1 = Valor(tramo+1, pieza, eje);
        const float m0 = Tangente(tramo, pieza, eje) * duracion;
        const float m1 = Tangente(tramo+1, pieza, eje) * duracion;
        const float u2 = u*u, u3 = u2*u;
        return (2*u3 - 3*u2 + 1)*p0 + (u3 - 2*u2 + u)*m0
             + (-2*u3 + 3*u2)*p1 + (u3 - u2)*m1;
    }

    size_t inicioOrbita = 0;
    Model modelos[4]; glm::vec3 centros[4];
    double tiempo = 0; size_t tramo = 0; bool reproduciendo = false;
    bool Error() const { std::cout << "ERROR: keyframescohete.txt invalido; secuencia anterior conservada.\n"; return false; }
};
