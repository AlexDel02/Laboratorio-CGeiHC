#pragma once
/*
  Keyframes.h  -  Practica 10: animacion por keyframes del cohete que se separa en fases

  Cada KEYFRAME (cuadro clave) guarda 17 numeros:
	NAVE (la parte del cohete que sigue unida y llega a orbitar):
		x y z      posicion de la base del cohete (el origen del modelo)
		cabeceo    grados sobre Z   (0 = apunta hacia arriba, negativo = se inclina hacia +X)
		guinada    grados sobre Y   (rumbo)
	ETAPAS (3 etapas que se separan y caen), para cada una:
		dx dy dz   desplazamiento del centro de la pieza desde el punto donde se separo
		giro       grados extra sobre Z que gira la pieza al caer
	Estos valores solo cuentan a partir del keyframe en que se separa la etapa.

  Entre dos keyframes consecutivos pasa DURACION_SEGMENTO segundos. La pose se calcula con una
  curva cubica de Hermite (pendientes de Catmull-Rom), asi no hay tirones al pasar por cada cuadro.

  Archivo de texto (keyframescohete.txt):
		# comentario
		separaciones 8 11 14     keyframe (desde 0) en que se separa cada etapa
		bucle 16                 (opcional) keyframe donde empieza la orbita que se repite;
								 el ultimo keyframe debe tener la misma pose que ese
		x y z cabeceo guinada | dx dy dz giro | dx dy dz giro | dx dy dz giro      <- un keyframe por linea
*/
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <cctype>

namespace kf
{
	const size_t MAX_FRAMES = 200;
	const int ETAPAS = 3;
	const int CANALES = 5 + 4 * ETAPAS;           // numeros por keyframe
	const float DURACION_SEGMENTO = 1.0f;         // segundos entre un keyframe y el siguiente

	struct Frame
	{
		float v[CANALES];
		Frame() { for (int i = 0; i < CANALES; i++) v[i] = 0.0f; }
		float x() const { return v[0]; }
		float y() const { return v[1]; }
		float z() const { return v[2]; }
		float cabeceo() const { return v[3]; }
		float guinada() const { return v[4]; }
		// etapa k (0..2): desplazamiento del centro y giro propio
		float ex(int k) const { return v[5 + 4 * k]; }
		float ey(int k) const { return v[6 + 4 * k]; }
		float ez(int k) const { return v[7 + 4 * k]; }
		float egiro(int k) const { return v[8 + 4 * k]; }
	};

	class Animacion
	{
	public:
		Animacion() { Vaciar(); }

		// ---------------- lista de keyframes ----------------
		bool Agregar(const Frame& f)
		{
			if (frames.size() >= MAX_FRAMES) return false;
			frames.push_back(f);
			return true;
		}
		void Vaciar()
		{
			frames.clear();
			for (int k = 0; k < ETAPAS; k++) separacion[k] = -1;
			bucle = -1;
		}
		size_t Cantidad() const { return frames.size(); }
		const Frame& Obtener(size_t i) const { return frames[i]; }
		int Separacion(int k) const { return separacion[k]; }          // -1 = esa etapa no se separa
		void FijarSeparacion(int k, int keyframe) { separacion[k] = keyframe; }
		int Bucle() const { return bucle; }                           // -1 = sin bucle
		void FijarBucle(int keyframe) { bucle = keyframe; }
		// tiempo del ultimo keyframe (la animacion "termina" ahi; con bucle la orbita sigue)
		float Duracion() const { return frames.size() < 2 ? 0.0f : (frames.size() - 1) * DURACION_SEGMENTO; }
		bool TieneBucle() const { return bucle >= 0 && frames.size() > 2 && bucle < (int)frames.size() - 1; }

		// ---------------- archivo externo ----------------
		// Escribe todos los keyframes. Si el archivo existe lo sobreescribe (ios::trunc).
		bool Guardar(const std::string& ruta) const
		{
			std::ofstream f(ruta.c_str(), std::ios::out | std::ios::trunc);
			if (!f.is_open()) return false;
			f << "# keyframescohete.txt - Practica 10: cohete que se separa en fases\n";
			f << "# Cada keyframe dura " << DURACION_SEGMENTO << " s. Columnas por keyframe:\n";
			f << "#   x y z cabeceo guinada | etapa0: dx dy dz giro | etapa1: dx dy dz giro | etapa2: dx dy dz giro\n";
			f << "separaciones " << separacion[0] << " " << separacion[1] << " " << separacion[2] << "\n";
			if (bucle >= 0) f << "bucle " << bucle << "\n";
			f << std::fixed << std::setprecision(3);
			for (const Frame& fr : frames)
			{
				for (int i = 0; i < CANALES; i++)
				{
					if (i == 5 || i == 9 || i == 13) f << "| ";
					float num = (std::fabs(fr.v[i]) < 0.0005f) ? 0.0f : fr.v[i];      // evita escribir -0.000
					f << num << (i + 1 < CANALES ? " " : "");
				}
				f << "\n";
			}
			f.flush();
			return f.good();
		}

		// Lee el archivo y REEMPLAZA la animacion actual. Si algo falla no cambia nada.
		bool Leer(const std::string& ruta)
		{
			std::ifstream f(ruta.c_str());
			if (!f.is_open()) return false;
			std::vector<Frame> nuevos;
			int sep[ETAPAS] = { -1, -1, -1 };
			int bu = -1;
			std::string linea;
			while (std::getline(f, linea))
			{
				size_t k = linea.find_first_not_of(" \t\r");
				if (k == std::string::npos || linea[k] == '#') continue;      // linea vacia o comentario
				if (std::isalpha((unsigned char)linea[k]))                    // directiva
				{
					std::istringstream ss(linea);
					std::string palabra;
					ss >> palabra;
					if (palabra == "separaciones") { for (int e = 0; e < ETAPAS; e++) if (!(ss >> sep[e])) return false; }
					else if (palabra == "bucle") { if (!(ss >> bu)) return false; }
					else return false;
					continue;
				}
				std::replace(linea.begin(), linea.end(), '|', ' ');           // el | solo separa columnas
				std::istringstream ss(linea);
				Frame fr;
				for (int i = 0; i < CANALES; i++) if (!(ss >> fr.v[i])) return false;
				nuevos.push_back(fr);
				if (nuevos.size() >= MAX_FRAMES) break;
			}
			int n = (int)nuevos.size();
			if (n < 2) return false;
			for (int e = 0; e < ETAPAS; e++) if (sep[e] < -1 || sep[e] >= n) return false;
			if (bu < -1 || bu >= n - 1) return false;
			frames = nuevos;
			for (int e = 0; e < ETAPAS; e++) separacion[e] = sep[e];
			bucle = bu;
			return true;
		}

		// ---------------- interpolacion ----------------
		// Pose en el instante t (segundos desde el inicio).
		//  - La nave sigue la animacion; con bucle, despues del ultimo keyframe repite la orbita.
		//  - Las etapas solo se mueven desde su keyframe de separacion; al terminar se quedan donde cayeron.
		Frame Evaluar(float t) const
		{
			Frame r;
			size_t n = frames.size();
			if (n == 0) return r;
			if (n == 1) return frames[0];
			float fin = Duracion();
			float tn = t;
			if (TieneBucle() && t > fin)
			{
				float ini = bucle * DURACION_SEGMENTO;
				tn = ini + std::fmod(t - ini, fin - ini);
			}
			for (int c = 0; c < 5; c++) r.v[c] = Canal(c, tn, 0);
			float tl = std::min(t, fin);
			for (int k = 0; k < ETAPAS; k++)
				if (separacion[k] >= 0)
					for (int j = 0; j < 4; j++) r.v[5 + 4 * k + j] = Canal(5 + 4 * k + j, tl, separacion[k]);
			return r;
		}

	private:
		std::vector<Frame> frames;
		int separacion[ETAPAS];
		int bucle;

		float P(int c, size_t i) const { return frames[i].v[c]; }

		// Pendiente (en unidades por segmento) del canal c en el keyframe i.
		// "inicio" es el primer keyframe en que ese canal existe.
		float Tangente(int c, size_t i, size_t inicio) const
		{
			size_t n = frames.size();
			bool nave = (c < 5);
			if (nave && TieneBucle() && (i == (size_t)bucle || i == n - 1))
			{
				// la orbita es un anillo cerrado: la pendiente en la union es la misma de los dos lados
				float delta = P(c, n - 1) - P(c, bucle);       // lo que suma el canal en una vuelta (ej. -360 de rumbo)
				float izq = P(c, n - 2) - delta;
				return (P(c, bucle + 1) - izq) * 0.5f;
			}
			if (i == inicio)
			{
				if (nave) return 0.0f;                          // la nave arranca en reposo
				if (i + 2 < n) return (-3.0f * P(c, i) + 4.0f * P(c, i + 1) - P(c, i + 2)) * 0.5f;   // sale con la velocidad que llevaba
				return (i + 1 < n) ? P(c, i + 1) - P(c, i) : 0.0f;
			}
			if (i == n - 1)
			{
				if (nave) return 0.0f;
				if (i >= inicio + 2) return (3.0f * P(c, i) - 4.0f * P(c, i - 1) + P(c, i - 2)) * 0.5f;
				return P(c, i) - P(c, i - 1);
			}
			return (P(c, i + 1) - P(c, i - 1)) * 0.5f;
		}

		// Valor del canal c en el instante t (curva cubica de Hermite entre dos keyframes)
		float Canal(int c, float t, size_t inicio) const
		{
			size_t n = frames.size();
			float ti = inicio * DURACION_SEGMENTO;
			if (t <= ti) return P(c, inicio);
			if (t >= Duracion()) return P(c, n - 1);
			float s = t / DURACION_SEGMENTO;
			size_t i = (size_t)s;
			if (i > n - 2) i = n - 2;
			float u = s - (float)i;
			float p0 = P(c, i), p1 = P(c, i + 1);
			float m0 = Tangente(c, i, inicio), m1 = Tangente(c, i + 1, inicio);
			float u2 = u * u, u3 = u2 * u;
			return (2 * u3 - 3 * u2 + 1) * p0 + (u3 - 2 * u2 + u) * m0
				+ (-2 * u3 + 3 * u2) * p1 + (u3 - u2) * m1;
		}
	};
}
